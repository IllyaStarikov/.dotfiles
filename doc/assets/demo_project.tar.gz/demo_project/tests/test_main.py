"""Tests for main module."""
import pytest

def test_main():
    assert True
