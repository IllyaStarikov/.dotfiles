"""Utility functions."""

def format_name(first, last):
    return f"{first} {last}"
