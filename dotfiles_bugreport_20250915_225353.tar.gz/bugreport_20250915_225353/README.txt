Dotfiles Bug Report
Generated: Mon Sep 15 22:54:06 PDT 2025
Report ID: 20250915_225353

This report contains diagnostic information about the dotfiles setup.
All sensitive information has been sanitized (unless --no-sanitize was used).

Contents:
- metadata.json: Report metadata and options
- system/: System and hardware information
- config/: Dotfiles and application configuration
- logs/: Recent log files (if included)
- tests/: Test results (if run)
- debug/: Additional debug information

To extract: tar -xzf dotfiles_bugreport_20250915_225353.tar.gz
